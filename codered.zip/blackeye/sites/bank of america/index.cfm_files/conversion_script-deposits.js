if (typeof(tagVars)=="undefined")
	tagVars = "";


if (typeof(lpUASunit)!="undefined")
	tagVars = tagVars + '&SESSIONVAR!Unit_Type=' + escape(lpUASunit);



if (typeof(lpUASrderTotal)!="undefined")
	tagVars = tagVars + '&PAGEVAR!OrderTotal=' + escape(lpUASorderTotal);

if (typeof(lpUASfunded_OrderTotal)!="undefined")
	tagVars = tagVars + '&PAGEVAR!Funded_OrderTotal=' + escape(lpUASfunded_OrderTotal);

if (typeof(lpUASusCitizen)!="undefined")
	tagVars = tagVars + '&PAGEVAR!USCitizen=' + escape(lpUASusCitizen);

if (typeof(lpUASapplicationState)!="undefined")
	tagVars = tagVars + '&PAGEVAR!ApplicationState=' + escape(lpUASapplicationState);

if (typeof(lpUASaid)!="undefined")
	tagVars = tagVars + '&PAGEVAR!ApplicationID=' + escape(lpUASaid);

if (typeof(lpUASconversionStage)!="undefined")
	tagVars = tagVars + '&PAGEVAR!ConversionStage=' + escape(lpUASconversionStage);

if (typeof(lpUASerrorCounter)!="undefined" && lpUASerrorCounter != "0" && lpUASerrorCounter != 0){
    tagVars = tagVars + '&PAGEVAR!ErrorCounter=' + escape(lpUASerrorCounter);
}



if (typeof(lpUASdeposits_OVP_ProductRemoved)!="undefined")
	tagVars = tagVars + '&PAGEVAR!Deposits_OVP_ProductRemoved=' + escape(lpUASdeposits_OVP_ProductRemoved);


if (typeof(lpUASdeposits_OVP_ProductTypeName1)!="undefined")
	tagVars = tagVars + '&PAGEVAR!Deposits_OVP_ProductTypeName1=' + escape(lpUASdeposits_OVP_ProductTypeName1);

if (typeof(lpUASdeposits_OVP_ProductTypeName2)!="undefined")
	tagVars = tagVars + '&PAGEVAR!Deposits_OVP_ProductTypeName2=' + escape(lpUASdeposits_OVP_ProductTypeName2);

if (typeof(lpUASdeposits_OVP_ProductTypeName3)!="undefined")
	tagVars = tagVars + '&PAGEVAR!Deposits_OVP_ProductTypeName3=' + escape(lpUASdeposits_OVP_ProductTypeName3);

if (typeof(lpUASdeposits_OVP_ProductTypeName4)!="undefined")
	tagVars = tagVars + '&PAGEVAR!Deposits_OVP_ProductTypeName4=' + escape(lpUASdeposits_OVP_ProductTypeName4);

if (typeof(lpUASdeposits_OVP_ProductTypeName5)!="undefined")
	tagVars = tagVars + '&PAGEVAR!Deposits_OVP_ProductTypeName5=' + escape(lpUASdeposits_OVP_ProductTypeName5);


if (typeof(lpUASdeposits_OVP_TotalAvailProducts)!="undefined")
	tagVars = tagVars + '&PAGEVAR!Deposits_OVP_TotalAvailProducts=' + escape(lpUASdeposits_OVP_TotalAvailProducts);

if (typeof(lpUASdeposits_OVP_TotalNumProductsApplied)!="undefined")
	tagVars = tagVars + '&PAGEVAR!Deposits_OVP_TotalNumProductsApplied=' + escape(lpUASdeposits_OVP_TotalNumProductsApplied);

if (typeof(lpUASdeposits_OVP_ProductsNotSelected)!="undefined")
	tagVars = tagVars + '&PAGEVAR!Deposits_OVP_ProductsNotSelected=' + escape(lpUASdeposits_OVP_ProductsNotSelected);

if (typeof(lpUASsection)!="undefined")
	tagVars = tagVars + '&PAGEVAR!Section=' + escape(lpUASsection);

if (typeof(lpUASstate)!="undefined")
	tagVars = tagVars + '&SESSIONVAR!State=' + escape(lpUASstate);



if (typeof(lpUASconversionDetails)!="undefined")
	tagVars = tagVars + '&PAGEVAR!ConversionDetails=' + escape(lpUASconversionDetails);

if (typeof(lpUASorderTotal)!="undefined")
	tagVars = tagVars + '&SESSIONVAR!Site-OrderTotal=' + escape(lpUASorderTotal);

if (typeof(lpUASconversionDetails)!="undefined")
	tagVars = tagVars + '&SESSIONVAR!Site-ConversionDetails=' + escape(lpUASconversionDetails);


if (typeof(lpUASfunded_OrderTotal)!="undefined")
	tagVars = tagVars + '&SESSIONVAR!Funded_Order-Total=' + escape(lpUASfunded_OrderTotal);


if (typeof(lpUASusCitizen)!="undefined")
	tagVars = tagVars + '&SESSIONVAR!Site-USCitizen=' + escape(lpUASusCitizen);


lpUAStrimTagvars();
