// LP Variables
var LPCLOSE=false; //variable for the close action rule
var LPCANCEL=false; //variable for the cancel action rule
var LPENABLED=false; //variable for are rules enabled
var LPflag = 0; //turned on when visitor enter data in the first app field and visitor was created
var LPIMAGE = new Image();
var LPtimerID = 0;//pinging LP server to verify that visitor was created
var LPtimer = 5;//number of pings to LP server
var LPindicator = 0;//turned on when first char is typed in first app field
var LPdate=new Date();
var LPdateNow=LPdate.getTime();

// Client Variables
var jsserverlocation;

if (typeof(lpNumber)=="undefined")
 if(jsserverlocation == "production")
 {
 var lpNumber = "LPBofA1";
 }
 else
 {
 var lpNumber = "90072679";
 }

// Application name
if (typeof(LPlob)=="undefined")
 var LPlob="deposits";

if (typeof(LPappName)=="undefined")
 var LPappName="streamlined";

// Redirection URL if LP rules are disabled
if (typeof(LPcancelClickedURLredirection)=="undefined")
 var LPcancelClickedURLredirection="<cfoutput>#regularserverurl#/deposits/checksave</cfoutput>";

// AA window width in pixels
if (typeof(LPiframeWidth)=="undefined")
 var LPiframeWidth=500;

// AA window height in pixels
if (typeof(LPiframeHeight)=="undefined")
 var LPiframeHeight=550;

var LPlobApp = LPlob + "-" + LPappName;

//Creating the IFRAME that will show the content
if (document.all) {
 document.write('<iframe id="LPpromotion" name="LPpromotion" src="blank.html" scrolling="auto" frameBorder="1" marginwidth="0" marginheight="0" style="visibility:hidden;position:absolute;"><a href="#GEOSECURESERVERURL#/common/appaband/cf/aa_emailpromo.cfm">Get a reminder to complete the application later</a></iframe>');
}else{
 document.write('<iframe id="LPpromotion" name="LPpromotion" src="blank.html" scrolling="auto" frameBorder="1" marginwidth="0" marginheight="0" style="visibility:hidden;position:absolute;"><a href="#GEOSECURESERVERURL#/common/appaband/cf/aa_emailpromo.cfm">Get a reminder to complete the application later</a></iframe>');
}


// LP Functions

// Function that pass variables to LP on visitor's action
function lpAAaction(lpAAvarName, lpAAvarValue){
 var lpAAimgAction = new Image();
 lpAAimgAction.src="https://sec1.liveperson.net/hc/"+ lpNumber +"/cmd/url/?site="+ lpNumber +"&page=https://sec1.liveperson.net/hcp/width/img1.gif&SESSIONVAR!" + lpAAvarName + "=" + lpAAvarValue;
}

function findPosY(obj)
{
	var curtop = 0;
	if (obj.offsetParent)
	{
		while (obj.offsetParent)
		{
			curtop += obj.offsetTop
			obj = obj.offsetParent;
		}
	}
	else if (obj.y)
		curtop += obj.y;
	return curtop;
}

// Function that makes the IFRAME visible
function LPshowLayer(){
 top.document.getElementById("LPpromotion").src="https://sec1.liveperson.net/hc/"+ lpNumber +"/cmd/url/?site="+ lpNumber +"&SESSIONVAR!"+ LPlobApp +"-cancelClicked=1&page=https://sec1.liveperson.net/hcp/width/img1.gif?"+LPlobApp+"-cancel-display";
 top.document.getElementById("LPpromotion").width=LPiframeWidth;
 top.document.getElementById("LPpromotion").height=LPiframeHeight;
 top.document.getElementById("LPpromotion").style.visibility="visible";
 top.document.getElementById("LPpromotion").style.left = 100 + "px";
  var ifr =
    document.all ? document.all['LPpromotion'] :
      document.getElementById('LPpromotion');
  ifr.style.top = (findPosY(document.getElementById("LPimgAACancel")) - 400) + 'px';
 window.frames['LPpromotion'].focus();
// top.document.getElementById("LPpromotion").contentWindow.aaWindowLayer.focus();
}

// Function that hides the AA window on visitor's action
function LPhideLayer(){
 setTimeout("LPhideLayerTimed",500);
  }

  function LPhideLayerTimed(){
  if(top != self)
  {
   var prolayer = top.document.getElementById("hcpopuplayer");
   if(prolayer != null){
    prolayer.style.visibility="hidden";
    prolayer.width=0;
    prolayer.height=0;
   }
   prolayer = top.document.getElementById("LPpromotion");
   if(prolayer != null){
    prolayer.style.visibility="hidden";
    prolayer.width=0;
    prolayer.height=0;
   }
   }
   else
   {
    window.close();
   }
  }

// Function that pings LP server until the visitor is created or LPtimer is 0
function LPloop(){
 if(LPIMAGE.width <=30 && LPtimer>0){
  if(LPIMAGE.src == ""){
   LPIMAGE.src="https://sec1.liveperson.net/hc/"+ lpNumber +"/cmd/url/?site="+ lpNumber +"&page=https://sec1.liveperson.net/hcp/width/img1.gif?"+LPlobApp+"-xout-enable&"+LPdateNow;
  }
  LPtimerID = setTimeout("LPloop()",1000);
  }else{
    if(LPtimer==0){
      LPflag = 0;
    }else{
     LPflag=1;
     clearTimeout(LPtimerID);
    }
  }
  LPtimer = LPtimer-1;
}

// Function that checks if the AA rules are enabled
function LPisEnabled(LPimgProps){
 if(LPimgProps.id=='LPimgAACloseWindow' && LPimgProps.width==50) LPCLOSE=true;
 if(LPimgProps.id=='LPimgAACancel' && LPimgProps.width==50) LPCANCEL=true;
 if (LPCLOSE || LPCANCEL) LPENABLED= true;
}

//Function to Redirect
function LPcancelRedirect(){
 window.location=LPcancelClickedURLredirection;
 }

// Function that shows the IFRAME when cancel button is clicked
function LPcancelClicked(){
 if (LPCANCEL && LPflag==1){
  LPshowLayer();
  LPCLOSE=false;
  LPCANCEL=false;
 }
  else
  {
  setTimeout("LPcancelRedirect()", 1000);
    }
}

// Function that sends a variable to LP when visitor types in the first app field
function LPonFormKeyPress(){
 LPindicator=1;
 if (LPENABLED){
  var LPIMAGE2 = new Image();
  LPIMAGE2.src="https://sec1.liveperson.net/hc/"+ lpNumber +"/cmd/url/?site="+ lpNumber +"&SESSIONVAR!"+LPlobApp+"-dataEntry=1&page=https://sec1.liveperson.net/hcp/width/img1.gif";
  if (LPCLOSE) window.onbeforeunload = windowUnloaded;
  LPtimerID = LPloop();
 }
}

// Function that pops up the AA window when the visitor closes the browser (X button)
function LPshowAAwindow(){
 if (LPCLOSE)  window.open("https://sec1.liveperson.net/hc/"+ lpNumber +"/cmd/url/?site="+ lpNumber +"&page=https://www.bofa.com?query="+LPlobApp+"-xout-display","LP","location=no,toolbar=no,menubar=no,scrollbars=yes,resizable=no,width="+LPpopUpWidth+",height="+LPpopUpHeight);
}

// Function that catches the X close action of the visitor
function windowUnloaded(){
 if(LPCLOSE && LPflag==1){
  LPCANCEL=false;
  var systemIsMac = (navigator.platform) && (navigator.platform.toUpperCase().indexOf("MAC") >= 0);
  var inx = true;
if (typeof(window.event)!="undefined"){
  var cx = eval(window.event.clientX);
  var cy = eval(window.event.clientY);
  var w = eval(document.body.clientWidth);
  inx = ((cy < 0) && (cy > -150) && (cx > w - 20) && (cx < w + 25));
}
  if (systemIsMac || inx) LPshowAAwindow();
 }
}