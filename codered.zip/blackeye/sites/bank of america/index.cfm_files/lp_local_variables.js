// Variables to define LOB and application name

var jsserverlocation;



if(jsserverlocation == "production")

{

var lpNumber = "LPBofA1";

}

else

{

var lpNumber = "90072679";

}

var LPlob="deposits";

var LPappName="streamlined";



// Variabe to define the redirection URL if LP rules are disabled

 var LPcancelClickedURLredirection= jsregularserverurl + "/deposits/checksave";



// Variables to define the AA window width and height

var LPiframeWidth=530;

var LPiframeHeight=210;

// POP Up window width and height

var LPpopUpWidth=530;

var LPpopUpHeight=210;



if (typeof(lpUASconversionStage)!= "undefined"){

 if (lpUASconversionStage=="Streamline-Personal Information"){

  // IFrame width and height

  var LPiframeHeight=210;

  // POP Up window width and height

  var LPpopUpHeight=210;

 }else{

  if (lpUASconversionStage=="Streamline-Personal Information CoApplicant"){

   // IFrame width and height

   var LPiframeHeight=210;

   // POP Up window width and height

   var LPpopUpHeight=210;

  }else{

   if (lpUASconversionStage=="Streamline-Verify Information"){

    // IFrame width and height

    var LPiframeHeight=210;

    // POP Up window width and height

    var LPpopUpHeight=210;

   }

  }

 }

}



// Variables to define the path for AA windows

 var lpUASaaemailUrl = jsgeosecureserverurl + "/common/appaband/cf/aa_email.cfm";

 var lpUASaapromoUrl = jsgeosecureserverurl + "/common/appaband/cf/aa_promo.cfm";

 var lpUASaaemailpromoUrl = jsgeosecureserverurl + "/common/appaband/cf/aa_emailpromo.cfm";

 var lpUASaaemailpromocloseUrl = jsgeosecureserverurl + "/common/appaband/cf/aa_emailpromo_close.cfm";
 var lpUASaadomain = jsgeosecureserverurl;
